package pass2;

public class Assembler
{
	LiteralTable LT[] =new LiteralTable[10];
	SymbolTable ST[] =new SymbolTable[10];
	int STP=0,LTP=0;
	int location_counter=0;
	public Assembler()
	{
	}
	
	public void pass2() throws Exception
	{
		
	}
	public static void main(String args[]) throws Exception
	{
		Assembler A =new Assembler();
		A.pass2();
		

	}


}