package pass2;

public class LiteralTable {

	String name;
	int add;
	public LiteralTable(String name,int add)
	{
		this.name=name;
		this.add=add;
	}
	
}
