package pass2;

public class SymbolTable {

		String name;
		int add;
		public SymbolTable(String name,int add)
		{
			this.name=name;
			this.add=add;
		}
	
}
