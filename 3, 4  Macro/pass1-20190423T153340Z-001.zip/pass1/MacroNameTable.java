package pass1;

public class MacroNameTable {
	int index=0,parameters=0;
	String name="";
	public MacroNameTable(String name , int index , int parameters) {
		this.index = index;
		this.name = name;
		this.parameters = parameters;
	}
}
